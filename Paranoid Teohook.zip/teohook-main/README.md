# teohook
teohook with fixed port

put the itemz.dat in cache folder of the growtopia folder.
inject with Extreme injector, or download process hacker 2 or cheat engine.

If growtopia crashes, make sure to put the items.dat uploaded here in cache folder of growtopia.

if you cant login with main gt, Open menu, go to Misc > disable login spoofing.

Discord: Rayy#5664. my old one got banned


